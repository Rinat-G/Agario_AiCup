package helper;


import dto.GameObject;

import java.util.ArrayList;

public class GameObjectHelper {

//    public static GameObject nearestTo(ArrayList<GameObject> gameObjectArrayList, int x, int y){
//        ///////////////////
//        return null;
//    }
}
