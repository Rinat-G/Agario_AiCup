package dto;

public class GameObjectEjection extends GameObject {


    public GameObjectEjection(float x, float y) {
        super(x, y, Type.Ejection);

    }




}
