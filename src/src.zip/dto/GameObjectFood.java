package dto;

public class GameObjectFood extends GameObject {


    public GameObjectFood(float x, float y) {
        super(x, y, Type.Food);
    }


}
