package dto;


public class GameObjectPoint extends  GameObject{
    public GameObjectPoint(float x, float y) {
        super(x, y, Type.Point);
    }
}
